Java scrpit Application Exam
==================================

```bash
$ tree
.
|-- index.html
|-- menu.html
|-- home.html
|-- register.html
|-- login.html
|-- createPost.html
|-- getPosts.html
|-- mocha-html-reporter.html
|-- scripts
|   |-- crowdShare
|   |   |--event.js
|   |   |--logic.js
|   |   |--ui.js
|   |    `-- httpRequest.js
|   `-- libs
|       |-- chai.js
|       |-- cryptojs.js
|       |-- handlebars.js
|       |-- jquery.js
|       |-- kendo.web.min.js
|       |-- mocha.js
|       |-- q.min.js
|       |-- require.js
|       |-- sammy-latest.min.js
|       |-- sha1.js
|       |-- sinon.js
|       `-- underscore.js
|-- styles
|   |-- Black
|   |   |--....  
|   |-- kendo.black.min.css
|   |-- kendo.common.min.css
|   |-- mocha.css
|   `-- styles.css
`-- tests
    |-- mochaTests.js
    `-- test-main.js

5 directories, 30+ files
```