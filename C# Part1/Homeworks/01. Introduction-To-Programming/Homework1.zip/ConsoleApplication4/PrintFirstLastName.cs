﻿using System;

class PrintFirstLastName
{
    static void Main()
    {
        Console.WriteLine("First name : John");
        Console.WriteLine("Last name  : Doe");
    }
}

