﻿using System;

class HelloCsharp
{
    static void Main()
    {
        Console.WriteLine("Hello C#");
    }
}
