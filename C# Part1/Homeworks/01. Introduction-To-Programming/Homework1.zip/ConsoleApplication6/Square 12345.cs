﻿using System;

class PrintSquare12345
{
    static void Main()
    {
        Console.WriteLine("Square from 12345 is: " + Math.Pow(12345,5));
    }
}

